"""Fixed communication delay experiment."""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]

if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(
        0,
        str(PROJECT_ROOT)
    )

from examples.run_multi_sat_interface import build_demo_case
from cooperative.multi_sat_pipeline import run_cooperative_pipeline
from cooperative.delay_channel import DelayChannel


def main():
    scenario, observations, initial_errors, modality_config = build_demo_case()

    channel = DelayChannel(
        delay_by_node={
            "sat_01": 0.0,
            "sat_02": 5.0,
            "sat_03": 10.0,
        }
    )

    result = run_cooperative_pipeline(
        scenario=scenario,
        observations_by_node=observations,
        initial_error_by_node=initial_errors,
        architecture="federated_ci",
        modality_config_by_node=modality_config,
        delay_channel=channel,
    )

    print("Delay experiment finished.")
    print("Position RMSE:", result.metrics.cooperative_position_rmse)
    print("Velocity RMSE:", result.metrics.cooperative_velocity_rmse)


if __name__ == "__main__":
    main()
