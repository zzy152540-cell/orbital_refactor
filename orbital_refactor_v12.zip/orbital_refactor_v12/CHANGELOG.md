# Orbital Refactor Change Log

## v12.1 - Asynchronous Time Alignment Fusion

### Added
- Added `cooperative/time_alignment.py`.
- Added delayed state alignment before CI fusion.
- Added a time propagation interface for future orbital dynamics based compensation.

### Modified
- Updated asynchronous fusion pipeline:
  - delayed reports are released by `MessageBuffer`;
  - released reports are propagated to current fusion epoch;
  - aligned reports are used for CI fusion.
- Kept example entry scripts using the project-root path insertion pattern.

### Notes
- Current time alignment uses a constant-velocity transition model as a baseline.
- Future versions can replace it with the full orbital dynamics/J2 propagation model.

## v12 - Asynchronous Fusion Base

### Added
- Message buffer based delayed communication processing.
- Arrival timestamp based report release.

## v11.1 - Delay Logging

### Added
- Delay configuration output.
- Source and arrival timestamp logging.
- Received node history recording.


## v12.2 - Orbital dynamics time alignment

### Added
- Replaced constant-velocity delayed-state alignment with two-body + J2 RK4 propagation.
- Added independent message buffer lifecycle per fusion run.

### Fixed
- Avoided communication buffer state leaking between repeated experiments.


## v12.3 - Age-aware CI weighting

### Added
- Added information-age based covariance inflation.
- Added optional age-aware CI weighting for asynchronous fusion.

### Modified
- Extended cooperative pipeline interfaces with:
  - `age_aware`
  - `age_penalty`

### Purpose
Reduce the influence of older asynchronous information during CI fusion.


## v12.4 - Cooperative experiment framework

### Added
- Added unified cooperative experiment entry script.
- Added JSON based cooperative experiment configuration.
- Added cooperative result summary export.

### Purpose
- Improve reproducibility and prepare delay/dropout/packet-loss comparative experiments.
