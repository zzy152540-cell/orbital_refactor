from __future__ import annotations

import numpy as np

from interfaces.data_objects import Observation


Array = np.ndarray


def create_infrared_observations(
    *,
    timestamps: Array,
    relative_position_spri: Array,
    covariance: Array,
    observer_id: str,
    target_id: str,
    rng: np.random.Generator,
    valid_flags: Array | None = None,
) -> list[Observation]:
    timestamps = np.asarray(timestamps, dtype=float).reshape(-1)
    position = np.asarray(relative_position_spri, dtype=float)
    covariance = np.asarray(covariance, dtype=float).reshape(2, 2)
    valid = _valid_array(valid_flags, len(timestamps))
    if position.shape != (len(timestamps), 3):
        raise ValueError("relative_position_spri must have shape (N, 3).")

    azimuth = np.arctan2(position[:, 1], position[:, 0])
    elevation = np.arctan2(position[:, 2], np.linalg.norm(position[:, :2], axis=1))
    noise = rng.multivariate_normal(np.zeros(2), covariance, size=len(timestamps))
    measurements = np.column_stack((azimuth, elevation)) + noise
    return _create_observations(
        timestamps=timestamps,
        measurements=measurements,
        covariance=covariance,
        valid=valid,
        observer_id=observer_id,
        target_id=target_id,
        modality="INFRARED",
        measurement_type="AZIMUTH_ELEVATION",
        frame="SPRI",
    )


def create_radar_observations(
    *,
    timestamps: Array,
    relative_position_spri: Array,
    relative_velocity_spri: Array,
    covariance: Array,
    observer_id: str,
    target_id: str,
    rng: np.random.Generator,
    valid_flags: Array | None = None,
) -> list[Observation]:
    timestamps = np.asarray(timestamps, dtype=float).reshape(-1)
    position = np.asarray(relative_position_spri, dtype=float)
    velocity = np.asarray(relative_velocity_spri, dtype=float)
    covariance = np.asarray(covariance, dtype=float).reshape(2, 2)
    valid = _valid_array(valid_flags, len(timestamps))
    if position.shape != (len(timestamps), 3) or velocity.shape != (len(timestamps), 3):
        raise ValueError("relative position and velocity must have shape (N, 3).")

    range_value = np.linalg.norm(position, axis=1)
    range_rate = np.sum(position * velocity, axis=1) / np.maximum(range_value, 1e-12)
    noise = rng.multivariate_normal(np.zeros(2), covariance, size=len(timestamps))
    measurements = np.column_stack((range_value, range_rate)) + noise
    return _create_observations(
        timestamps=timestamps,
        measurements=measurements,
        covariance=covariance,
        valid=valid,
        observer_id=observer_id,
        target_id=target_id,
        modality="RADAR",
        measurement_type="RANGE_RANGE_RATE",
        frame="SPRI",
    )


def apply_dropout_windows(valid_flags: Array, timestamps: Array, windows: list[tuple[float, float]] | None) -> Array:
    valid = np.asarray(valid_flags, dtype=bool).copy().reshape(-1)
    timestamps = np.asarray(timestamps, dtype=float).reshape(-1)
    if valid.shape != timestamps.shape:
        raise ValueError("valid_flags and timestamps must have the same shape.")
    for start, end in windows or []:
        if end < start:
            raise ValueError("Dropout window end must not precede start.")
        valid[(timestamps >= float(start)) & (timestamps <= float(end))] = False
    return valid


def _create_observations(
    *,
    timestamps: Array,
    measurements: Array,
    covariance: Array,
    valid: Array,
    observer_id: str,
    target_id: str,
    modality: str,
    measurement_type: str,
    frame: str,
) -> list[Observation]:
    return [
        Observation(
            timestamp=float(timestamps[index]),
            observer_id=observer_id,
            target_id=target_id,
            modality=modality,
            source_type="TRADITIONAL",
            measurement=measurements[index].copy(),
            covariance=covariance.copy(),
            confidence=1.0,
            frame=frame,
            valid_flag=bool(valid[index]),
            metadata={"measurement_type": measurement_type},
        )
        for index in range(len(timestamps))
    ]


def _valid_array(valid_flags: Array | None, length: int) -> Array:
    if valid_flags is None:
        return np.ones(length, dtype=bool)
    valid = np.asarray(valid_flags, dtype=bool).reshape(-1)
    if valid.shape != (length,):
        raise ValueError("valid_flags must have shape (N,).")
    return valid
