from __future__ import annotations

from interfaces.data_objects import NodeReport


class MessageBuffer:
    """Simple delayed message buffer."""

    def __init__(self):
        self._buffer: list[NodeReport] = []

    def push(self, report: NodeReport):
        self._buffer.append(report)

    def pop_available(self, current_time: float) -> list[NodeReport]:
        available = []
        remain = []
        for report in self._buffer:
            arrival = (
                report.arrival_timestamp
                if report.arrival_timestamp is not None
                else report.timestamp
            )
            if arrival <= current_time:
                available.append(report)
            else:
                remain.append(report)
        self._buffer = remain
        return available
