from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from interfaces.data_objects import NodeReport
from orbital_core.ci_fusion import ci_fuse_posteriors
from orbital_core.quality import quality_score_from_covariance

Array = np.ndarray


@dataclass(frozen=True)
class CooperativeFusionHistory:
    timestamps: Array
    state_history_eci: Array
    covariance_history: Array
    node_weight_history: list[dict[str, float]]
    active_node_history: list[list[str]]


def relative_history_to_absolute(
    relative_state_history_eci: Array,
    observer_state_history_eci: Array,
) -> Array:
    relative = np.asarray(relative_state_history_eci, dtype=float)
    observer = np.asarray(observer_state_history_eci, dtype=float)
    if relative.shape != observer.shape or relative.ndim != 2 or relative.shape[1] != 6:
        raise ValueError("Relative and observer histories must both have shape (N, 6).")
    return relative + observer


def fuse_node_reports(
    reports: list[NodeReport],
    *,
    objective: str = "trace",
    grid_points: int = 31,
) -> tuple[Array, Array, dict[str, float]]:
    valid = [report for report in reports if report.valid_flag]
    if not valid:
        raise ValueError("No valid node reports are available for fusion.")
    result = ci_fuse_posteriors(
        [(report.node_id, report.state_estimate, report.covariance) for report in valid],
        objective=objective,
        grid_points=grid_points,
    )
    return result.state, result.covariance, result.weights


def fuse_local_histories(
    *,
    timestamps: Array,
    relative_state_history_by_node: dict[str, Array],
    covariance_history_by_node: dict[str, Array],
    observer_state_history_by_node: dict[str, Array],
    target_id: str,
    validity_history_by_node: dict[str, Array] | None = None,
    objective: str = "trace",
    grid_points: int = 31,
) -> CooperativeFusionHistory:
    """Convert local relative histories to absolute ECI and fuse them at each epoch."""
    timestamps = np.asarray(timestamps, dtype=float).reshape(-1)
    node_ids = list(relative_state_history_by_node)
    if not node_ids:
        raise ValueError("At least one node history is required.")
    if len(node_ids) > 3:
        raise ValueError("The current simultaneous CI core supports at most three nodes.")

    absolute = {
        node_id: relative_history_to_absolute(
            relative_state_history_by_node[node_id], observer_state_history_by_node[node_id]
        )
        for node_id in node_ids
    }
    fused_states = np.zeros((len(timestamps), 6))
    fused_covariances = np.zeros((len(timestamps), 6, 6))
    weight_history: list[dict[str, float]] = []
    active_history: list[list[str]] = []

    for index, timestamp in enumerate(timestamps):
        reports: list[NodeReport] = []
        for node_id in node_ids:
            covariance = np.asarray(covariance_history_by_node[node_id][index], dtype=float)
            valid = True if validity_history_by_node is None else bool(validity_history_by_node[node_id][index])
            reports.append(NodeReport(
                node_id=node_id,
                target_id=target_id,
                timestamp=float(timestamp),
                state_estimate=absolute[node_id][index].copy(),
                covariance=covariance.copy(),
                quality_score=quality_score_from_covariance(covariance),
                health_status="NORMAL" if valid else "UNAVAILABLE",
                communication_delay=0.0,
                valid_flag=valid,
            ))
        active_nodes = [report.node_id for report in reports if report.valid_flag]
        if active_nodes:
            state, covariance, weights = fuse_node_reports(
                reports, objective=objective, grid_points=grid_points
            )
        elif index > 0:
            # During a complete communication outage, hold the last cooperative
            # posterior rather than terminating the full simulation.
            state = fused_states[index - 1].copy()
            covariance = fused_covariances[index - 1].copy()
            weights = {}
        else:
            raise ValueError("No valid node report is available at the initial epoch.")
        fused_states[index] = state
        fused_covariances[index] = covariance
        weight_history.append(weights)
        active_history.append(active_nodes)

    return CooperativeFusionHistory(
        timestamps=timestamps.copy(),
        state_history_eci=fused_states,
        covariance_history=fused_covariances,
        node_weight_history=weight_history,
        active_node_history=active_history,
    )
