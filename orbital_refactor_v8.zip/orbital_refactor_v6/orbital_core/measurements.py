from __future__ import annotations

from typing import Callable

import numpy as np

from .coordinates import rotate_eci_to_pri, state_eci_to_spri


def wrap_angle(a: np.ndarray) -> np.ndarray:
    return (np.asarray(a, dtype=float) + np.pi) % (2.0 * np.pi) - np.pi


def h_optical_spri(x_rel_eci: np.ndarray, q_eci2pri: np.ndarray) -> np.ndarray:
    r = state_eci_to_spri(x_rel_eci, q_eci2pri)[:3]
    if abs(r[2]) < 1e-12:
        raise ValueError("光学量测模型中 z 分量过小。")
    return np.array([r[0] / r[2], r[1] / r[2]], dtype=float)


def h_nn_position_eci(x_rel_eci: np.ndarray, q_eci2pri: np.ndarray) -> np.ndarray:
    del q_eci2pri
    return np.asarray(x_rel_eci, dtype=float)[:3].copy()


def h_nn_position_velocity_eci(
    x_rel_eci: np.ndarray,
    q_eci2pri: np.ndarray,
) -> np.ndarray:
    del q_eci2pri
    return np.asarray(x_rel_eci, dtype=float).copy()


def h_nn_position_spri(x_rel_eci: np.ndarray, q_eci2pri: np.ndarray) -> np.ndarray:
    return rotate_eci_to_pri(np.asarray(x_rel_eci, dtype=float)[:3], q_eci2pri)


def h_nn_position_velocity_spri(
    x_rel_eci: np.ndarray,
    q_eci2pri: np.ndarray,
) -> np.ndarray:
    return state_eci_to_spri(x_rel_eci, q_eci2pri).copy()


def h_ir_spri(x_rel_eci: np.ndarray, q_eci2pri: np.ndarray) -> np.ndarray:
    r = state_eci_to_spri(x_rel_eci, q_eci2pri)[:3]
    rho_xy = np.hypot(r[0], r[1])
    return np.array([np.arctan2(r[1], r[0]), np.arctan2(r[2], rho_xy)], dtype=float)


def h_radar_spri(x_rel_eci: np.ndarray, q_eci2pri: np.ndarray) -> np.ndarray:
    state = state_eci_to_spri(x_rel_eci, q_eci2pri)
    r, v = state[:3], state[3:]
    rho = np.linalg.norm(r)
    if rho <= 0.0:
        raise ValueError("雷达量测模型中距离必须大于零。")
    return np.array([rho, float(r @ v) / rho], dtype=float)


def measurement_residual(z: np.ndarray, z_pred: np.ndarray, mode: str) -> np.ndarray:
    residual = np.asarray(z, dtype=float) - np.asarray(z_pred, dtype=float)
    if mode.lower() == "ir":
        residual = wrap_angle(residual)
    return residual


def numerical_measurement_jacobian(
    h: Callable[[np.ndarray], np.ndarray],
    x: np.ndarray,
    eps: float = 1e-6,
) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    hx = np.asarray(h(x), dtype=float)
    jac = np.zeros((hx.size, x.size), dtype=float)
    for i in range(x.size):
        step = eps * max(1.0, abs(float(x[i])))
        xp = x.copy(); xp[i] += step
        xm = x.copy(); xm[i] -= step
        jac[:, i] = (np.asarray(h(xp)) - np.asarray(h(xm))) / (2.0 * step)
    return jac
