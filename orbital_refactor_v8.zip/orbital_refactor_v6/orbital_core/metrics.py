from __future__ import annotations

import numpy as np


def compute_rmse(error: np.ndarray) -> float:
    error = np.asarray(error, dtype=float)
    if error.size == 0:
        raise ValueError("误差数组不能为空。")
    if error.ndim == 1:
        return float(np.sqrt(np.mean(error**2)))
    return float(np.sqrt(np.mean(np.sum(error**2, axis=1))))
